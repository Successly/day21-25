package cn.itcast.demo2;
/*
 * String s = "abc";final char[] value
 */
public class Demo {
	public static void main(String[] args) {
		int[] arr = {1};
		System.out.println(arr);
		
		char[] ch = {'a','b'};
		System.out.println(ch);
		
		byte[] b = {};
		System.out.println(b);
	}
}
