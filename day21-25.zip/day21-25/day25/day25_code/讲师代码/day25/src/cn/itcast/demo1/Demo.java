package cn.itcast.demo1;

public class Demo {
	public static void main(String[] args) {
		Person p = new Person("a",22);
		System.out.println(p);
	}
}
